import re
import argparse
import os
import base64
import json
import hashlib
from datetime import datetime



MIN_LENGTH = 4
MAX_FILE_SIZE = 1 * 1024 * 1024 * 1024  # 1 GB
CHUNK_SIZE = 1024 * 1024  # 1 MB

KEYWORDS = ["password", "pass", "pwd", "username", "user", "login", "email"]

# -------------------------------
# LEGAL & FORENSIC WARNING (CLO 1)
# -------------------------------
def print_legal_warning():
    print("\n=== DIGITAL FORENSICS NOTICE ===")
    print("[!] This tool is for authorized forensic use only.")
    print("[!] Unauthorized analysis of data may violate privacy laws.")
    print("[!] Ensure proper legal permission before use.\n")

# -------------------------------
# CHECK FILE SIZE
# -------------------------------
def check_file_size(file_path):
    size = os.path.getsize(file_path)
    print(f"[*] File size: {size / (1024*1024):.2f} MB")

    if size > MAX_FILE_SIZE:
        print("[!] File exceeds 1GB limit. Aborting...")
        return False
    return True

# -------------------------------
# HASH FOR EVIDENCE INTEGRITY (CLO 1)
# -------------------------------
def calculate_hash(file_path):
    sha256 = hashlib.sha256()

    with open(file_path, "rb") as f:
        while True:
            chunk = f.read(8192)
            if not chunk:
                break
            sha256.update(chunk)

    return sha256.hexdigest()

# -------------------------------
# STRING EXTRACTION
# -------------------------------
def extract_strings_from_chunk(chunk):
    pattern = rb"[ -~]{4,}"
    raw_strings = re.findall(pattern, chunk)
    return [s.decode(errors="ignore") for s in raw_strings]

# -------------------------------
# FILE PROCESSING
# -------------------------------
def process_file(file_path):
    all_strings = []

    with open(file_path, "rb") as f:
        while True:
            chunk = f.read(CHUNK_SIZE)
            if not chunk:
                break

            strings = extract_strings_from_chunk(chunk)
            all_strings.extend(strings)

    return all_strings

# -------------------------------
# FILTER STRINGS
# -------------------------------
def filter_strings(strings):
    return list(set([s.strip() for s in strings if len(s.strip()) >= MIN_LENGTH]))

# -------------------------------
# EMAIL EXTRACTION
# -------------------------------
def extract_emails(strings):
    email_pattern = re.compile(
        r"\b[a-zA-Z0-9._%+-]{3,}@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,10}\b"
    )

    emails = set()

    for s in strings:
        found = email_pattern.findall(s)

        for e in found:
            if ".." in e or "@." in e or ".@" in e:
                continue

            if len(e.split("@")[-1]) < 4:
                continue

            emails.add(e.lower())

    return list(emails)

# -------------------------------
# BASE64 DECODING
# -------------------------------
def try_base64_decode(strings):
    decoded = []

    for s in strings:
        try:
            if len(s) % 4 == 0 and re.match(r'^[A-Za-z0-9+/=]+$', s):
                d = base64.b64decode(s).decode("utf-8", errors="ignore")

                if len(d) < 6:
                    continue

                if any(k in d.lower() for k in KEYWORDS):
                    decoded.append(d)

        except:
            continue

    return decoded

# -------------------------------
# CREDENTIAL EXTRACTION
# -------------------------------
def extract_credentials(strings):
    patterns = [
        re.compile(r"\b(username|user|login)\s*[:=]\s*([^\s\"';]{3,})", re.I),
        re.compile(r"\b(password|pass|pwd)\s*[:=]\s*([^\s\"';]{4,})", re.I),
    ]

    blacklist = {
        "begin", "end", "null", "none", "true", "false",
        "prompt", "not", "set", "trayicon", "user", "password"
    }

    credentials = []

    for s in strings:
        for pattern in patterns:
            match = pattern.search(s)

            if match:
                key = match.group(1).lower()
                value = match.group(2).strip()

                val_lower = value.lower()

                # ❌ filter junk
                if val_lower in blacklist:
                    continue

                if any(x in value for x in ["%s", "%ws", "%d"]):
                    continue

                if len(value) < 4:
                    continue

                credentials.append({
                    "type": key,
                    "value": value,
                    "raw": s
                })

    return credentials

# -------------------------------
# CONFIDENCE SCORING
# -------------------------------
def assign_confidence(entry):
    val = entry["value"].lower()
    raw = entry["raw"].lower()

    score = 0

    if "=" in raw or ":" in raw:
        score += 2

    if any(k in raw for k in ["password", "pwd"]):
        score += 3

    if any(k in raw for k in ["user", "login"]):
        score += 2

    if len(val) >= 6:
        score += 2

    if any(x in val for x in ["*", "****"]):
        score += 1

    # final classification
    if score >= 6:
        return "HIGH"
    elif score >= 4:
        return "MEDIUM"
    elif score >= 2:
        return "LOW"
    else:
        return "UNKNOWN"

    

# -------------------------------
# CLASSIFICATION
# -------------------------------
def classify_data(strings):
    emails = extract_emails(strings)
    decoded_strings = try_base64_decode(strings)
    credentials = extract_credentials(strings + decoded_strings)

    classified = []

    for c in credentials:
        classified.append({
            "value": c,
            "confidence": assign_confidence(c)
        })

    return emails, classified, decoded_strings

def remove_noise(strings):
    noise_keywords = [
        "error", "failed", "debug", "trace", "enter", "exit",
        "handle", "process", "malloc", "logonuser", "exception"
    ]

    clean = []

    for s in strings:
        s_lower = s.lower()

        # remove system logs
        if any(n in s_lower for n in noise_keywords):
            continue

        # remove format strings
        if "%" in s:
            continue

        # remove very short garbage
        if len(s.strip()) < 4:
            continue

        clean.append(s)

    return clean

# -------------------------------
# OUTPUT TXT (CLO 3)
# -------------------------------
def write_output_txt(strings, emails, credentials, decoded, output_file, file_hash):
    with open(output_file, "w", encoding="utf-8") as f:

        f.write("=== FORENSIC REPORT ===\n")
        f.write(f"Generated on: {datetime.now()}\n")
        f.write(f"SHA-256 Hash: {file_hash}\n")
        f.write("NOTE: This report may contain sensitive data.\n\n")

        f.write("==== EMAILS ====\n")
        for e in emails:
            f.write(e + "\n")

        f.write("\n==== DECODED BASE64 ====\n")
        for d in decoded:
            f.write(d + "\n")

        f.write("\n==== CREDENTIALS ====\n")
        for c in credentials:
            f.write(f"{c['value']}  [{c['confidence']}]\n")

        f.write("\n==== ALL STRINGS ====\n")
        for s in strings:
            f.write(s + "\n")

    print(f"[+] TXT Output saved: {output_file}")

# -------------------------------
# OUTPUT JSON (CLO 3)
# -------------------------------
def write_output_json(emails, credentials, decoded, output_file, file_hash):
    report = {
        "forensic_info": {
            "timestamp": str(datetime.now()),
            "hash_sha256": file_hash,
            "integrity": "verified (read-only)"
        },
        "emails": emails,
        "decoded_strings": decoded,
        "credentials": credentials,
        "summary": {
            "total_emails": len(emails),
            "total_credentials": len(credentials),
            "decoded_entries": len(decoded)
        }
    }

    json_file = output_file.replace(".txt", ".json")

    with open(json_file, "w", encoding="utf-8") as f:
        json.dump(report, f, indent=4)

    print(f"[+] JSON Report saved: {json_file}")

# -------------------------------
# MAIN
# -------------------------------
def main():
    parser = argparse.ArgumentParser(description="Advanced Password Parser (Forensic Tool)")
    parser.add_argument("input", help="Memory dump file")
    parser.add_argument("-o", "--output", default="results.txt")

    args = parser.parse_args()

    # 📁 FIXED OUTPUT DIRECTORY (ALWAYS uploads folder)
    output_dir = r"C:\Users\User\Downloads\Password_Parser\Password_Parser\uploads"

    # 🧱 Ensure folder exists
    os.makedirs(output_dir, exist_ok=True)

    # 📄 Final output path (whatever name user gives)
    output_path = os.path.join(output_dir, os.path.basename(args.output))

    print_legal_warning()

    # ❌ File validation
    if not os.path.exists(args.input):
        print("[!] File not found")
        return

    if not check_file_size(args.input):
        return

    print("[*] Forensic Mode: READ-ONLY (Evidence will not be modified)")

    # 🔐 Integrity hash
    file_hash = calculate_hash(args.input)
    print(f"[*] SHA-256 Hash: {file_hash}")

    print("[*] Processing file...")

    # 📄 Extract memory strings
    strings = process_file(args.input)
    print(f"[+] Extracted strings: {len(strings)}")

    # 🧹 Clean pipeline
    filtered = filter_strings(strings)
    filtered = remove_noise(filtered)

    # 🔍 Analysis engine
    emails, credentials, decoded = classify_data(filtered)

    print(f"[+] Emails found: {len(emails)}")
    print(f"[+] Credentials found: {len(credentials)}")
    print(f"[+] Base64 decoded entries: {len(decoded)}")

    # 💾 OUTPUT (ALWAYS uploads folder)
    write_output_txt(filtered, emails, credentials, decoded, output_path, file_hash)
    write_output_json(emails, credentials, decoded, output_path, file_hash)

    print(f"[✔] Analysis complete. Output saved at:\n{output_path}")


if __name__ == "__main__":
    main()