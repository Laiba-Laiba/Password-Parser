import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import subprocess
import os

def browse_input():
    path = filedialog.askopenfilename(
        title="Select Memory Dump",
        filetypes=[("Memory Files", "*.raw *.img *.mem"), ("All Files", "*.*")]
    )
    if path:
        input_var.set(path)

def browse_output():
    path = filedialog.asksaveasfilename(
        defaultextension=".txt",
        filetypes=[("Text Files", "*.txt")]
    )
    if path:
        output_var.set(path)

import threading

def run_analysis():
    thread = threading.Thread(target=run_analysis_thread)
    thread.start()

def run_analysis_thread():
    input_file = input_var.get()
    output_file = output_var.get() or "results.txt"

    if not input_file:
        messagebox.showerror("Error", "Select input file")
        return

    if not os.path.exists(input_file):
        messagebox.showerror("Error", "File not found")
        return

    try:
        status_var.set("Processing...")
        progress.start()

        subprocess.run(
            ["python", "Pass_parser.py", input_file, "-o", output_file],
            check=True
        )

        status_var.set("Completed ✅")
        messagebox.showinfo("Done", f"Saved to:\n{output_file}")

    except subprocess.CalledProcessError as e:
        status_var.set("Error ❌")
        messagebox.showerror("Error", str(e))

    finally:
        progress.stop()


# ---------------- GUI ----------------
root = tk.Tk()
root.title("Forensic Password Parser")
root.geometry("520x300")
root.resizable(False, False)

# Variables
input_var = tk.StringVar()
output_var = tk.StringVar()
status_var = tk.StringVar(value="Idle")

# Style
style = ttk.Style()
style.theme_use("clam")

# Title
ttk.Label(root, text="Forensic Password Parser", font=("Arial", 16, "bold")).pack(pady=10)

# Input
frame1 = ttk.Frame(root)
frame1.pack(pady=5)

ttk.Entry(frame1, textvariable=input_var, width=45).pack(side="left", padx=5)
ttk.Button(frame1, text="Browse", command=browse_input).pack(side="left")

# Output
frame2 = ttk.Frame(root)
frame2.pack(pady=5)

ttk.Entry(frame2, textvariable=output_var, width=45).pack(side="left", padx=5)
ttk.Button(frame2, text="Save As", command=browse_output).pack(side="left")

# Run Button
ttk.Button(root, text="Run Analysis", command=run_analysis).pack(pady=15)

# Progress bar
progress = ttk.Progressbar(root, mode="indeterminate")
progress.pack(fill="x", padx=20, pady=5)

# Status
ttk.Label(root, textvariable=status_var).pack()

root.mainloop()