Password Parser (RAM Forensics Tool)
Password Parser is a digital memory forensics tool made to extract sensitive information from memory dumps which in this case is especially passwords but email addresses and encoded data is also extracted.
the tool helps a digital forensic investigator to identify and extract sensitive information from volatile memory which is often stored as plaintext.

Features:
Extracts human readable strings from volatile memory dumps
Detects email addresses
Identifies credentials such as usernames and passwords
Decodes base 64 encoded data
It also assigns confidence levels of high, medium or low
It generates forensic reports in TXT and JSON formats
Provides SHA-256 hashing for integrity checks
GUI based interface is for ease of user

Dependencies and Prerequisites
Python 3.8 or higher
No external libraries required but built in libraries of python are required
Minimum 4GB RAM and 500MB free Disk space

Installation Instructions
Install python from https://www.python.org
Download the project files from github repository
Ensure python is added to system path
place project in a directory same as memory dump files


Execution
Run tool using command: 
python Pass_parser.py <input_file> -o <output_file>
example: python Pass_parser.py memory.raw -o results.txt

Graphical User Interface (GUI)
Run GUI: python Pass_parser_GUI.py
Click Browse to select memory dump file
Click save as to choose output file
Click Run analysis

Output
This tool generates:
1.TXT Report which contains extracted emails, decoded base64 strings, credentails with confidence levels and all extracted strings
2.JSON Report which contains forensic metadata such as timestamps and SHA-256 hash along with structured data of emails, credentails and decoded data. It also contains summary statistics.

Platform Compatibility
Windows
Linux
macOS

Troubleshooting
Issues along with their respective solutions are listed below:
1. If file not found check the file path again
2. If python not recognized check add the python to PATH
3. If large file error then ensure that file is under 1GB

Limitations:
works only on readable memory dumps
can not guarantee all credentails are valid
Base 64 decoding limited to valid formats

Future Improvements
PDF report generation
Advanced keyword filtering
Support for additional encoding formats

Ethical Notice
This tool is strictly made to use solely for digital forensic investigation and education purposes and any unauthorized use that may violate any privacy law is strictly prohibited

Author
Developed as part of CY-3006 Digital Forensics semester project by Sukina Raveen, Laiba Nasir and Rania Muskan Malik.